In my experience: In Ryujinx if you test the mod with OpenGL Ryujinx crashes or directly the game doesn't load after the menu i.e. it freezes. 

However, if you switch to Vulkan the game works but has visual bug problems (ghosting when running on foot or on horseback).

In Yuzu: The game works with OpenGL. I don't know if it has some visual bug, maybe some flickering.

If you use Vulkan at the moment it has many visual bugs and in my case it has been almost impossible to play it with Vulkan.

Tested on: 

- Ryujinx 1.1.996
- Yuzu EA 3817

PC Specs: AMD Ryzen 5600, GTX 1080, 16GB RAM

CREDITS:

StevensND

https://github.com/StevensND
https://www.reddit.com/user/StevenssND
https://gbatemp.net/members/stevensnd.438828/