How to use it:

1. Extract the .zip file (These mods won't work if you just copy the .zip file into the mod directory). Then Open the folder corresponding to the region of your game.
2. Grab the folders inside and paste them into your Yuzu/Ryujinx mods directory. (On Yuzu/Ryujinx, right click on the game and Open Mod Directory or something similar.
3. Be sure you just enable one resolution mod. DON'T ENABLE ALL. At the start you will have ALL enable, unselect the ones that you don't want to use. 

Paste the mods folders in this path.

Path example in my case: D:\Emuladores\Yuzu\Yuzu EA\user\load\01004800197F0000

In this path I paste the folders 60 FPS [EU] + 1080p (In my case Normal, not 125 version) and both mods should be work properly. YOU NEED BOTH MODS (1080p + 60fps) TO MANTAIN 60FPS ALL THE TIME.

DISCLAIMER: This is the "v2.1 version" of the mod. This new version contains changes made by me and tested by me and other people on Reddit to verify that everything works properly and as it should.

New Credits to: StevenssND (v2.1 + v2 creator) + Random Guy on the 4chan forum who uploaded the resolution mods.
 
Old Credits to: jason098 (FPS mod creator apparently despite having learned how to do the mod and get similar code.), Timo654 (for sharing it on Ryujinx Discord), Issou15 (for sharing jason098 + Timo654 mods on Reddit).

CHANGELOG:

5 July 2023: v2.1 Fix rain drops on the ground, added new 1080p mod version + new version of the 60fps mod.

4 July 2023: v2 had rain-drops on the ground not working if you were using 1080p mod.

This version maintains 60fps when you close Yuzu/Ryujinx. Previously this didn't happen with version v1 (made by me, StevenssND). 

03 July 2023: v1 only worked at 60fps the first time you ran the game, if you closed Yuzu/Ryujinx, the game stayed all the time at 30fps and to fix it, you had to delete a file (SystemSave) to make it work at 60fps again.