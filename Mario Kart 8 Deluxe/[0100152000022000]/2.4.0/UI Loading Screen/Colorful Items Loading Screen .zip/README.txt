How to use it:

1. Unzip the file. If you just copy & paste the .zip it won't work.

2. Open Yuzu/Ryujinx. Righ click on the game and then click on Open Mod Directory (or similar)

3. Paste Colorful Items Loading Screen Folder into that path/directory.

BE SURE YOUR PATH/DIRECTORY FOLLOWS THIS STRUCTURE: load\0100152000022000 

You've to paste Colorful Items Loading Screen Folder there.

-----------------------------------------------------------------------------------------------------------------------

Designed by StevensND 

- Support my work on Ko-Fi: https://ko-fi.com/stevenss

- Github: https://github.com/StevensND

- Reddit: https://www.reddit.com/user/StevenssND

- Gamebanana: https://gamebanana.com/members/2745830




